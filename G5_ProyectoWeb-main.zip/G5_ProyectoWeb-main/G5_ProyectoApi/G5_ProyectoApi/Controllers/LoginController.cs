﻿using Dapper;
using G5_ProyectoApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace G5_ProyectoApi.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public LoginController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        [Route("RegistrarCuenta")]
        public IActionResult RegistrarCuenta(UsuarioModel model)
        {
            var respuesta = new RespuestaModel();

            try
            {
                using (var context = new SqlConnection(_configuration.GetSection("ConnectionStrings:BDConnection").Value))
                {
                    var idRolExists = context.Query<int>(
                        "SELECT COUNT(1) FROM dbo.Rol WHERE IdRol = @IdRol",
                        new { model.IdRol }
                    ).FirstOrDefault() > 0;

                    if (!idRolExists)
                    {
                        respuesta.Indicador = false;
                        respuesta.Mensaje = $"El IdRol {model.IdRol} no existe en la tabla Rol.";
                        return BadRequest(respuesta); 
                    }

                    var result = context.Execute("RegistrarCuenta",
                        new
                        {
                            model.Identificacion,
                            model.Nombre,
                            model.Apellido,
                            model.Correo,
                            model.Contrasenna,
                            model.Imagen,
                            model.Activo,
                            model.TieneContrasennaTemp,
                            model.FechaVencimientoTemp,
                            model.IdRol
                        });

                    if (result > 0)
                    {
                        respuesta.Indicador = true;
                        respuesta.Mensaje = "Su información se ha registrado correctamente.";
                        return Ok(respuesta); 
                    }
                    else
                    {
                        respuesta.Indicador = false;
                        respuesta.Mensaje = "Su información no se ha registrado correctamente.";
                        return BadRequest(respuesta);
                    }
                }
            }
            catch (Microsoft.Data.SqlClient.SqlException ex)
            {
             
                respuesta.Indicador = false;
                respuesta.Mensaje = $"Error de base de datos: {ex.Message}";
                return StatusCode(500, respuesta); 
            }
            catch (Exception ex)
            {
                // Handle other exceptions
                respuesta.Indicador = false;
                respuesta.Mensaje = $"Error inesperado: {ex.Message}";
                return StatusCode(500, respuesta);
            }
        }


        [HttpPost]
        [Route("IniciarSesion")]
        public IActionResult IniciarSesion([FromBody] LoginRequestModel model)
        {
            using var context = new SqlConnection(_configuration.GetConnectionString("BDConnection"));

            var result = context.QueryFirstOrDefault<dynamic>("IniciarSesion",
                new
                {
                    Correo = model.Correo,
                    Contrasena = model.Contrasenna
                },
                commandType: CommandType.StoredProcedure);

            if (result == null || result.IdUsuario == null)
            {
                return BadRequest(new RespuestaModel
                {
                    Indicador = false,
                    Mensaje = result?.MensajeError ?? "Error al iniciar sesión"
                });
            }

            var usuario = new UsuarioModel
            {
                IdUsuario = result.IdUsuario,
                IdRol = result.IdRol,
                Identificacion = result.Identificacion ?? string.Empty,
                Nombre = result.Nombre ?? string.Empty,
                Apellido = result.Apellido ?? string.Empty,
                Correo = result.Correo ?? string.Empty,
                Contrasenna = model.Contrasenna,
                Imagen = result.Imagen ?? string.Empty,
                Activo = result.Activo,
                TieneContrasennaTemp = result.TieneContrasennaTemp,
                FechaVencimientoTemp = result.FechaVencimientoTemp
            };

            return Ok(new RespuestaModel
            {
                Indicador = true,
                Datos = usuario
            });
        }
    }
}
