﻿using Dapper;
using G5_ProyectoApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace G5_ProyectoApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PedidoController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public PedidoController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetPedidos")]
        public IActionResult GetPedidos([FromQuery] FiltroPedidoModel filtro)
        {
            try
            {
                using (var context = new SqlConnection(_configuration.GetSection("ConnectionStrings:BDConnection").Value))
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@Estado", filtro.Estado);
                    parameters.Add("@FechaInicio", filtro.FechaInicio);
                    parameters.Add("@FechaFin", filtro.FechaFin);
                    parameters.Add("@Cliente", filtro.Cliente);

                    var result = context.Query<PedidoModel>("GetPedidos", parameters, commandType: CommandType.StoredProcedure);

                    var respuesta = new RespuestaModel();

                    if (result != null && result.Any())
                    {
                        respuesta.Indicador = true;
                        respuesta.Datos = result;
                    }
                    else
                    {
                        respuesta.Indicador = false;
                        respuesta.Mensaje = "No hay pedidos que coincidan con los filtros especificados.";
                    }

                    return Ok(respuesta);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new RespuestaModel
                {
                    Indicador = false,
                    Mensaje = "Error al obtener los pedidos: " + ex.Message
                });
            }
        }

        [HttpGet]
        [Route("GetDetallePedido/{idPedido}")]
        public IActionResult GetDetallePedido(long idPedido)
        {
            using (var context = new SqlConnection(_configuration.GetSection("ConnectionStrings:BDConnection").Value))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@IdPedido", idPedido);

                var result = context.Query<DetallePedidoModel>("GetDetallePedido", parameters, commandType: CommandType.StoredProcedure);

                var respuesta = new RespuestaModel();

                if (result != null && result.Any())
                {
                    respuesta.Indicador = true;
                    respuesta.Datos = result;
                }
                else
                {
                    respuesta.Indicador = false;
                    respuesta.Mensaje = "No hay detalles para este pedido.";
                }

                return Ok(respuesta);
            }
        }
    }
}