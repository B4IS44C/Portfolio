﻿using Dapper;
using G5_ProyectoApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Reflection;

namespace G5_ProyectoApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public ProductoController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        [Route("RegistrarProducto")]
        public IActionResult RegistrarProducto(ProductoModel model)
        {
            using (var context = new SqlConnection(_configuration.GetSection("ConnectionStrings:BDConnection").Value))
            {
                model.IdCategoria = 1;
                var result = context.Execute("RegistrarProducto",
                    new { model.Nombre, model.Descripcion, model.Precio, model.Cantidad, model.Imagen, model.IdCategoria });

                var respuesta = new RespuestaModel();

                if (result > 0)
                    respuesta.Indicador = true;
                else
                {
                    respuesta.Indicador = false;
                    respuesta.Mensaje = "Producto registrado correctamente";
                }

                return Ok(respuesta);
            }
        }

        [HttpGet]
        [Route("GetProductos")]
        public IActionResult GetProductos(long Id)
        {
            using (var context = new SqlConnection(_configuration.GetSection("ConnectionStrings:BDConnection").Value))
            {
                var result = context.Query<ProductoModel>("GetProductos",
                new { Id });

                var respuesta = new RespuestaModel();
                if (result != null)
                {
                    respuesta.Indicador = true;
                    respuesta.Datos = result;
                }
                else
                {
                    respuesta.Indicador = false;
                    respuesta.Mensaje = "No hay informacion registrada!";
                }

                return Ok(respuesta);
            }
        }

        [HttpPost]
        [Route("DeleteProducto")]
        public IActionResult DeleteProducto(ProductoModel model)
        {
            using (var context = new SqlConnection(_configuration.GetSection("ConnectionStrings:BDConnection").Value))
            {
                var result = context.Query<ProductoModel>("DeleteProducto",
                new { @Id = model.IdProducto });

                var respuesta = new RespuestaModel();
                if (result != null)
                {
                    respuesta.Indicador = true;
                    respuesta.Datos = result;
                }
                else
                {
                    respuesta.Indicador = false;
                    respuesta.Mensaje = "Ha ocurrido un error!";
                }

                return Ok(respuesta);
            }
        }
    }
}
