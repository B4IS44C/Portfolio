﻿namespace G5_ProyectoApi.Models
{
    public class UsuarioModel
    {
        public long IdUsuario { get; set; }
        public long IdRol { get; set; }
        public required string Identificacion { get; set; }
        public required string Nombre { get; set; }
        public required string Apellido { get; set; }
        public required string Correo { get; set; }
        public required string Contrasenna { get; set; }
        public required string Imagen { get; set; }
        public bool Activo { get; set; }
        public bool TieneContrasennaTemp { get; set; }
        public DateTime? FechaVencimientoTemp { get; set; }
    }
}
