﻿namespace G5_ProyectoApi.Models
{
    public class CategoriaModel
    {
        public long IdCategoria { get; set; }

        public string? Nombre { get; set; }

    }
}
