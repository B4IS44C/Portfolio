﻿namespace G5_ProyectoApi.Models
{
    public class DetallePedidoModel
    {
        public long IdDetalle { get; set; }  
        public long IdPedido { get; set; }
        public long IdProducto { get; set; }
        public string? NombreProducto { get; set; }
        public int Cantidad { get; set; }
        public double PrecioUnitario { get; set; }
        public double Subtotal { get; set; }
    }
}