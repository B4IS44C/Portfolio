﻿namespace G5_ProyectoApi.Models
{
    public class PedidoModel
    {
        public long IdPedido { get; set; }
        public DateTime FechaPedido { get; set; }
        public string? Estado { get; set; }
        public double Total { get; set; }
        public string? Cliente { get; set; }
        public string? Direccion { get; set; }
        public string? Telefono { get; set; }
        public string? Email { get; set; }
        public List<DetallePedidoModel>? Detalles { get; set; }
    }
}
