﻿namespace G5_ProyectoApi.Models
{
    public class LoginRequestModel
    {
        public required string Correo { get; set; }
        public required string Contrasenna { get; set; }
    }
}
