﻿namespace G5_ProyectoWeb.Models
{
    public class CategoriaModel
    {
        public long IdCategoria { get; set; }

        public string? Nombre { get; set; }
    }
}
