﻿using System.ComponentModel.DataAnnotations;

namespace G5_ProyectoWeb.Models
{
    public class LoginRequestModel
    {
        public required string Correo { get; set; }
        public required string Contrasenna { get; set; }
    }
}