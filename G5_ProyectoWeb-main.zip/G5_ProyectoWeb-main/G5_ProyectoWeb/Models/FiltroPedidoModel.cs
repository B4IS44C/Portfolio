﻿namespace G5_ProyectoWeb.Models
{
    public class FiltroPedidoModel
    {
        public string? Estado { get; set; }
        public DateTime? FechaInicio { get; set; }
        public DateTime? FechaFin { get; set; }
        public string? Cliente { get; set; }
    }
}