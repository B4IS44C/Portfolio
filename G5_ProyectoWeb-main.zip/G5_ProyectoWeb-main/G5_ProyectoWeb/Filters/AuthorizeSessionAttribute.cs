﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace G5_ProyectoWeb.Filters
{
    public class AuthorizeSessionAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var session = context.HttpContext.Session;
            var userId = session.GetString("IdUsuario");

            if (string.IsNullOrEmpty(userId)) // Si no hay sesión iniciada
            {
                context.Result = new RedirectToRouteResult(new RouteValueDictionary
                {
                    { "controller", "Login" },
                    { "action", "IniciarSesion" }
                });
            }

            base.OnActionExecuting(context);
        }
    }
}
