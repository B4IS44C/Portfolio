﻿using G5_ProyectoWeb.Models;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace G5_ProyectoWeb.Controllers
{
    public class AdminController : Controller
    {
        private readonly IHttpClientFactory _httpClient;
        private readonly IConfiguration _configuration;

        public AdminController(IHttpClientFactory httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult Pedidos(FiltroPedidoModel filtro)
        {
            List<PedidoModel> pedidos = new List<PedidoModel>();

            using (var http = _httpClient.CreateClient())
            {
                string queryString = "";

                if (!string.IsNullOrEmpty(filtro.Estado))
                    queryString += $"Estado={filtro.Estado}&";
                if (filtro.FechaInicio.HasValue)
                    queryString += $"FechaInicio={filtro.FechaInicio.Value.ToString("yyyy-MM-dd")}&";
                if (filtro.FechaFin.HasValue)
                    queryString += $"FechaFin={filtro.FechaFin.Value.ToString("yyyy-MM-dd")}&";
                if (!string.IsNullOrEmpty(filtro.Cliente))
                    queryString += $"Cliente={filtro.Cliente}&";

             
                if (!string.IsNullOrEmpty(queryString))
                    queryString = "?" + queryString.TrimEnd('&');

                var url = _configuration.GetSection("Variables:urlWebApi").Value + "Pedido/GetPedidos" + queryString;
                var response = http.GetAsync(url).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadFromJsonAsync<RespuestaModel>().Result;

                    if (result != null && result.Indicador && result.Datos != null)
                    {
                        pedidos = JsonSerializer.Deserialize<List<PedidoModel>>((JsonElement)result.Datos!) ?? new List<PedidoModel>();
                    }
                }
            }

            ViewBag.Filtro = filtro;
            return View(pedidos);
        }

        [HttpGet]
        public IActionResult DetallePedido(long id)
        {
            PedidoModel pedido = new PedidoModel();
            List<DetallePedidoModel> detalles = new List<DetallePedidoModel>();

            using (var http = _httpClient.CreateClient())
            {
                var urlDetalles = _configuration.GetSection("Variables:urlWebApi").Value + $"Pedido/GetDetallePedido/{id}";
                var responseDetalles = http.GetAsync(urlDetalles).Result;

                if (responseDetalles.IsSuccessStatusCode)
                {
                    var resultDetalles = responseDetalles.Content.ReadFromJsonAsync<RespuestaModel>().Result;

                    if (resultDetalles != null && resultDetalles.Indicador && resultDetalles.Datos != null)
                    {
                        detalles = JsonSerializer.Deserialize<List<DetallePedidoModel>>((JsonElement)resultDetalles.Datos!) ?? new List<DetallePedidoModel>();
                    }
                }
            }

            pedido.IdPedido = id;
            pedido.Detalles = detalles;

            return View(pedido);
        }
    }
}