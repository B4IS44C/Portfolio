﻿using G5_ProyectoWeb.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Text.Json;

namespace G5_ProyectoWeb.Controllers
{
    public class MenuController : Controller
    {
        private readonly IHttpClientFactory _httpClient;
        private readonly IConfiguration _configuration;
        public MenuController(IHttpClientFactory httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _configuration = configuration;
        }


        [HttpGet]
        public IActionResult Menu()
        {
            List<ProductoModel> productos = new List<ProductoModel>();
            List<CategoriaModel> categorias = new List<CategoriaModel>();

            using (var http = _httpClient.CreateClient())
            {
                var urlProductos = _configuration.GetSection("Variables:urlWebApi").Value + "Producto/GetProductos";
                var responseProductos = http.GetAsync(urlProductos).Result;

                if (responseProductos.IsSuccessStatusCode)
                {
                    var result = responseProductos.Content.ReadFromJsonAsync<RespuestaModel>().Result;

                    if (result != null && result.Indicador && result.Datos != null)
                    {
                        productos = JsonSerializer.Deserialize<List<ProductoModel>>((JsonElement)result.Datos!) ?? new List<ProductoModel>();
                    }
                }

                var urlCategorias = _configuration.GetSection("Variables:urlWebApi").Value + "Categoria/GetCategorias";
                var responseCategorias = http.GetAsync(urlCategorias).Result;

                if (responseCategorias.IsSuccessStatusCode)
                {
                    var resultCategorias = responseCategorias.Content.ReadFromJsonAsync<RespuestaModel>().Result;

                    if (resultCategorias != null && resultCategorias.Indicador && resultCategorias.Datos != null)
                    {
                        categorias = JsonSerializer.Deserialize<List<CategoriaModel>>((JsonElement)resultCategorias.Datos!) ?? new List<CategoriaModel>();
                    }
                }
            }

            ViewBag.Categorias = categorias;
            return View(productos);
        }



    }
}
