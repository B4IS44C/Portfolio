﻿using Microsoft.AspNetCore.Mvc;

namespace G5_ProyectoWeb.Controllers
{
    public class AboutController : Controller
    {
        public IActionResult About()
        {
            return View();
        }
    }
}
