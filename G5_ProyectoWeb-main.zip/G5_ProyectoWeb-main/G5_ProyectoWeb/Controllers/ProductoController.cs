﻿using G5_ProyectoWeb.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Text.Json;

namespace G5_ProyectoWeb.Controllers
{
    public class ProductoController : Controller
    {

        private readonly IHttpClientFactory _httpClient;
        private readonly IConfiguration _configuration;
        public ProductoController(IHttpClientFactory httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _configuration = configuration;
        }

        [HttpPost]
        public IActionResult RegistrarProducto(ProductoModel model)
        {
            using (var http = _httpClient.CreateClient())
            {
                var url = _configuration.GetSection("Variables:urlWebApi").Value + "Producto/RegistrarProducto";
                var response = http.PostAsJsonAsync(url, model).Result;

                if (response.IsSuccessStatusCode)
                    return RedirectToAction("ConsultarProductos", "Producto");
            }

            return View();
        }

        [HttpGet]
        public IActionResult RegistrarProducto()
        {
            using (var http = _httpClient.CreateClient())
            {
                var url = _configuration.GetSection("Variables:urlWebApi").Value + "Categoria/GetCategorias";
                var response = http.GetAsync(url).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadFromJsonAsync<RespuestaModel>().Result;

                    if (result != null && result.Indicador && result.Datos != null)
                    {
                        var categorias = JsonSerializer.Deserialize<List<CategoriaModel>>((JsonElement)result.Datos!);

                        if (categorias != null)
                        {
                            ViewBag.CategoriasLista = new SelectList(categorias, "IdCategoria", "Nombre");
                        }
                    }
                }
            }

            return View();
        }

        [HttpGet]
        public IActionResult ConsultarProductos()
        {
            List<ProductoModel> productos = new List<ProductoModel>();

            using (var http = _httpClient.CreateClient())
            {
                var url = _configuration.GetSection("Variables:urlWebApi").Value + "Producto/GetProductos";
                var response = http.GetAsync(url).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadFromJsonAsync<RespuestaModel>().Result;

                    if (result != null && result.Indicador && result.Datos != null)
                    {
                        productos = JsonSerializer.Deserialize<List<ProductoModel>>((JsonElement)result.Datos!) ?? new List<ProductoModel>();

                    }
                }
            }
            return View(productos);
        }


        [HttpPost]
        public IActionResult DeleteProducto(ProductoModel model)
        {
            try
            {
                using (var http = _httpClient.CreateClient())
                {
                    var url = _configuration.GetSection("Variables:urlWebApi").Value + "Producto/DeleteProducto";
                    var response = http.PostAsJsonAsync(url, model).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        var result = response.Content.ReadFromJsonAsync<RespuestaModel>().Result;

                        if (result?.Indicador == true)
                        {
                            TempData["Mensaje"] = "Producto eliminado correctamente.";
                        }
                        else
                        {
                            TempData["Error"] = "No se pudo eliminar el producto.";
                        }
                    }
                    else
                    {
                        TempData["Error"] = "Error al conectar con el servidor.";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["Error"] = "Ocurrió un error inesperado: " + ex.Message;
            }

            return RedirectToAction("ConsultarProductos");
        }

    }
}
