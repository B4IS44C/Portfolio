﻿    using G5_ProyectoWeb.Models;
    using Microsoft.AspNetCore.Mvc;
    using System.Text.Json;
    using System.Diagnostics;
    using Microsoft.AspNetCore.Http;
    using G5_ProyectoWeb.Filters;

    namespace G5_ProyectoWeb.Controllers
    {
    public class LoginController : Controller
    {
        private readonly IHttpClientFactory _httpClient;
        private readonly IConfiguration _configuration;
        private readonly ILogger<LoginController> _logger;

        public LoginController(
            IHttpClientFactory httpClient,
            IConfiguration configuration,
            ILogger<LoginController> logger)
        {
            _httpClient = httpClient;
            _configuration = configuration;
            _logger = logger;
        }

        [HttpGet]
        public IActionResult IniciarSesion()
        {
            if (!string.IsNullOrEmpty(HttpContext.Session.GetString("IdUsuario")))
            {
                return RedirectToAction("Index", "Home"); 
            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> IniciarSesion(LoginRequestModel model)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Intento de inicio de sesión con modelo inválido");
                return View(model);
            }

            try
            {
                using var http = _httpClient.CreateClient();
                var apiUrl = _configuration["Variables:urlWebApi"] + "Login/IniciarSesion";
                _logger.LogInformation($"Enviando solicitud de inicio de sesión a {apiUrl}");

                var loginData = new { Correo = model.Correo, Contrasenna = model.Contrasenna };
                var response = await http.PostAsJsonAsync(apiUrl, loginData);

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Error en inicio de sesión. Status: {response.StatusCode}");
                    ModelState.AddModelError(string.Empty, "Correo o contraseña incorrectos.");
                    return View(model);
                }

                var responseContent = await response.Content.ReadAsStringAsync();
                var result = JsonSerializer.Deserialize<RespuestaModel>(responseContent);

                if (result == null || !result.Indicador)
                {
                    _logger.LogWarning("Inicio de sesión fallido: " + (result?.Mensaje ?? "Sin mensaje de error"));
                    ModelState.AddModelError(string.Empty, result?.Mensaje ?? "Credenciales inválidas");
                    return View(model);
                }

                var usuario = JsonSerializer.Deserialize<UsuarioModel>(result.Datos?.ToString() ?? "{}");
                if (usuario == null)
                {
                    _logger.LogError("No se pudo deserializar el usuario");
                    ModelState.AddModelError(string.Empty, "Error al procesar la respuesta");
                    return View(model);
                }

                HttpContext.Session.SetString("Nombre", usuario.Nombre ?? "Usuario");
                HttpContext.Session.SetString("Correo", usuario.Correo);
                HttpContext.Session.SetString("IdUsuario", usuario.IdUsuario.ToString());

                _logger.LogInformation($"Usuario {usuario.Correo} ha iniciado sesión correctamente");
                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al intentar iniciar sesión");
                ModelState.AddModelError(string.Empty, "Ocurrió un error al procesar su solicitud");
                return View(model);
            }
        }

        [HttpPost]
        public IActionResult CerrarSesion()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("IniciarSesion");
        }

        [HttpGet]
        public IActionResult RegistrarCuenta()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> RegistrarCuenta(UsuarioModel model)
        {
            _logger.LogInformation("Iniciando proceso de registro para: {Correo}", model.Correo);

            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Modelo inválido en registro. Errores: {@Errors}",
                    ModelState.Values.SelectMany(v => v.Errors));
                return View(model);
            }

            try
            {
                using var http = _httpClient.CreateClient();
                var apiUrl = _configuration["Variables:urlWebApi"] + "Login/RegistrarCuenta";

                _logger.LogInformation("Enviando solicitud de registro a {ApiUrl}", apiUrl);

                var response = await http.PostAsJsonAsync(apiUrl, model);

                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError("Error en registro. Status: {StatusCode}, Response: {ErrorContent}",
                        response.StatusCode, errorContent);

                    ModelState.AddModelError(string.Empty,
                        $"Error al registrar: {TryParseErrorMessage(errorContent)}");
                    return View(model);
                }

                var result = await response.Content.ReadFromJsonAsync<RespuestaModel>();

                if (result == null || !result.Indicador)
                {
                    _logger.LogWarning("Registro fallido: {Mensaje}", result?.Mensaje);
                    ModelState.AddModelError(string.Empty, result?.Mensaje ?? "Error al registrar la cuenta");
                    return View(model);
                }

                _logger.LogInformation("Registro exitoso para: {Correo}", model.Correo);
                TempData["MensajeExito"] = "¡Cuenta creada exitosamente! Por favor inicie sesión.";
                return RedirectToAction("IniciarSesion");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al registrar cuenta");
                ModelState.AddModelError(string.Empty, "Ocurrió un error inesperado al registrar la cuenta");
                return View(model);
            }
        }

        private string TryParseErrorMessage(string errorContent)
        {
            try
            {
                var errorObj = JsonSerializer.Deserialize<JsonElement>(errorContent);
                if (errorObj.TryGetProperty("message", out var message))
                    return message.GetString() ?? errorContent;
                if (errorObj.TryGetProperty("error", out var error))
                    return error.GetString() ?? errorContent;
                return errorContent;
            }
            catch
            {
                return errorContent;
            }
        }
        [HttpGet]
        public IActionResult RecuperarContrasenna()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> RecuperarContrasenna(RecuperarContrasennaModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            TempData["SuccessMessage"] = "Se ha enviado un enlace para restablecer tu contraseña a tu correo electrónico.";
            return RedirectToAction("IniciarSesion");
        }
    }
}